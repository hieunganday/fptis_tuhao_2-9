# avatar_fptis_30.4.2025
Hòa chung không khí kỷ niệm 50 năm ngày Giải phóng miền Nam, thống nhất đất nước (30/4/1975 - 30/4/2025), người FIS hãy cùng nhau thay avatar với khung hình đặc biệt, lan tỏa tinh thần tự hào dân tộc và niềm tin vào tương lai! Chỉ cần upload ảnh, căn chỉnh theo ý thích, ghép khung và tải về trong vài giây!
